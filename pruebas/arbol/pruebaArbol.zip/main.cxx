// proyecto de estructuras
// Diego Alejandro Cardozo Rojas, Brayan Estiben Giraldo Lopoez, David Alejandro Antolinez Socha

#include <iostream>
#include <fstream>
#include <deque>
#include <algorithm>
#include "arbol.h"


int main(int argc, char *argv[])
{
    Tree<char> arbol;
    char linea = 'h';

    arbol.insertar1(linea);
}