#ifndef __UTILIDADES_H__
#define __UTILIDADES_H__

#include <iostream>

void impresionAyuda();
void impresionAyudaEspecifico(std::string);

#include "utilidades.hxx"

#endif // __UTILIDADES_H__